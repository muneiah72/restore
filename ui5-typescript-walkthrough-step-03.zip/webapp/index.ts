import Text from "sap/m/Text";

new Text({
    text: "Hello World"
}).placeAt("content");
